import { Observable } from "../include/observable.js";
// Extra Credit Functions
export function classifyObservables(obsArr) {
    // TODO: Implement this function
    const negative = new Observable();
    const odd = new Observable();
    const rest = new Observable();
    obsArr.forEach(obs => {
        obs.subscribe(x => {
            if (x < 0)
                negative.update(x);
            else if (x % 2 === 1)
                odd.update(x);
            else
                rest.update(x);
        });
    });
    return { negative, odd, rest };
}
export function obsStrCond(funcArr, f, o) {
    // TODO: Implement this function
    const output = new Observable();
    o.subscribe(str => {
        let transformed = str;
        for (const fn of funcArr) {
            transformed = fn(transformed);
        }
        if (!f(transformed))
            output.update(str);
        else
            output.update(transformed);
    });
    return output;
}
export function statefulObserver(o) {
    // TODO: Implement this function
    const output = new Observable();
    let prev = null;
    o.subscribe(curr => {
        if (prev !== null && prev !== 0 && curr % prev === 0) {
            output.update(curr);
        }
        prev = curr;
    });
    return output;
}
// Optional Additional Practice
export function classifyTypeObservables(obsArr) {
    const string = new Observable();
    const number = new Observable();
    const boolean = new Observable();
    obsArr.forEach(obs => {
        obs.subscribe(x => {
            if (typeof x === "string")
                string.update(x);
            else if (typeof x === "number")
                number.update(x);
            else
                boolean.update(x);
        });
    });
    // TODO: Implement this function
    return { string, number, boolean };
}
export function mergeMax(o1, o2) {
    // TODO: Implement this function
    let largest = -Infinity;
    const output = new Observable();
    const f = (id) => (v) => {
        if (v >= largest) {
            output.update({ obs: id, v });
            largest = v;
        }
    };
    o1.subscribe(f(1));
    o2.subscribe(f(2));
    return output;
}
export function merge(o1, o2) {
    // TODO: Implement this function
    const output = new Observable();
    o1.subscribe(x => output.update(x));
    o2.subscribe(x => output.update(x));
    return output;
}
export class GreaterAvgObservable extends Observable {
    constructor() {
        super();
    }
    greaterAvg() {
        // TODO: Implement this method
        let prev1 = Infinity;
        let prev2 = Infinity;
        const output = new Observable();
        this.subscribe(x => {
            if (((prev1 + prev2) * 3) / 4 <= x)
                output.update(x);
            prev1 = prev2;
            prev2 = x;
        });
        return output;
    }
}
export class SignChangeObservable extends Observable {
    constructor() {
        super();
    }
    signChange() {
        // TODO: Implement this method
        const output = new Observable();
        let previous = 0;
        this.subscribe(x => {
            if (x !== 0 && previous * x <= 0)
                output.update(x);
            previous = x;
        });
        return output;
    }
}
/**
 * This function shows how the class you created above could be used.
 * @param numArr Array of numbers
 * @param f Observer function
 */
export function usingSignChange(numArr, f) {
    // TODO: Implement this function
    const obs = new SignChangeObservable();
    const scObs = obs.signChange();
    scObs.subscribe(f);
    numArr.forEach(x => obs.update(x));
}
//# sourceMappingURL=observables.js.map