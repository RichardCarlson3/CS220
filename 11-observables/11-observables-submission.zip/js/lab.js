// Exercise 1
export class MouseEvents {
    _num_screens;
    _subscribers;
    _is_valid_screen(screen) {
        return screen >= 0 && screen < this._num_screens;
    }
    constructor(num_screens) {
        this._num_screens = num_screens;
        this._subscribers = [];
        for (let i = 0; i < num_screens; i++) {
            const new_set = new Set();
            this._subscribers.push(new_set);
        }
    }
    subscribe(subscriber) {
        if (this._is_valid_screen(subscriber.screen)) {
            this._subscribers[subscriber.screen].add(subscriber);
        }
        // TODO: Implement this method
    }
    unsubscribe(subscriber) {
        if (this._is_valid_screen(subscriber.screen)) {
            this._subscribers[subscriber.screen].delete(subscriber);
        }
        // TODO: Implement this method
    }
    mouse_click(screen, coord) {
        // TODO: Implement this method
        if (this._is_valid_screen(screen)) {
            for (const subscriber of this._subscribers[screen]) {
                subscriber.update_coordinate(coord);
            }
        }
    }
    mouse_drag(screen, start, end) {
        // TODO: Implement this method
        if (this._is_valid_screen(screen)) {
            for (const subscriber of this._subscribers[screen]) {
                subscriber.update_drag(start, end);
            }
        }
    }
}
// Exercise 2
// Should print out all coordinate and mouse drag updates for a specific screen
export class MouseEventLogger {
    screen;
    constructor(screen) {
        this.screen = screen;
    }
    update_coordinate(coord) {
        console.log(`Click: (${coord.x}, ${coord.y})`);
        // TODO: Implement this method
    }
    update_drag(start, end) {
        console.log(`Drag: (${start.x}, ${start.y}) to (${end.x}, ${end.y})`);
        // TODO: Implement this method
    }
}
// Should print out area of bounding box around all mouse clicks, and area of bounding box for mouse drags
export class MouseEventArea {
    screen;
    _min_vals;
    _max_vals;
    calculate_area(corner1, corner2) {
        return Math.abs((corner1.x - corner2.x) * (corner1.y - corner2.y));
    }
    constructor(screen) {
        this.screen = screen;
        this._min_vals = { x: Infinity, y: Infinity };
        this._max_vals = { x: -1, y: -1 };
    }
    update_coordinate(coord) {
        this._min_vals.x = Math.min(this._min_vals.x, coord.x);
        this._min_vals.y = Math.min(this._min_vals.y, coord.y);
        this._max_vals.x = Math.max(this._max_vals.x, coord.x);
        this._max_vals.y = Math.max(this._max_vals.y, coord.y);
        const area = this.calculate_area(this._min_vals, this._max_vals);
        console.log(`Coordinate area: ${area}`);
    }
    update_drag(start, end) {
        // TODO: Implement this method
        const area = this.calculate_area(start, end);
        console.log(`Dragged area: ${area}`);
    }
}
//# sourceMappingURL=lab.js.map