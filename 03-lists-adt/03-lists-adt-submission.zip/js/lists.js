import { node, empty } from "../include/lists.js";
export function insertOrdered(lst, el) {
    if (lst.isEmpty())
        return node(el, empty());
    else if (lst.head() >= el)
        return node(el, lst);
    else
        return node(lst.head(), insertOrdered(lst.tail(), el));
}
export function everyNRev(lst, n) {
    let curSize = 0;
    return lst.reduce((acc, e) => {
        curSize++;
        return curSize % n === 0 ? node(e, acc) : acc;
    }, empty());
}
function reverse(lst) {
    return lst.reduce((acc, e) => node(e, acc), empty());
}
export function everyNCond(lst, n, cond) {
    let curSize = 0;
    const newList = lst.filter(cond);
    return reverse(newList.reduce((acc, e) => {
        curSize++;
        if (curSize % n === 0 && cond(e)) {
            return node(e, acc);
        }
        else
            return acc;
    }, empty()));
}
export function keepTrendMiddles(lst, allSatisfy) {
    let newList = empty();
    if (lst.isEmpty())
        return newList;
    else if (lst.tail().isEmpty())
        return newList;
    else if (lst.tail().tail().isEmpty())
        return newList;
    let lprev = lst.head();
    let lnext = lst.tail().tail();
    let lcurrList = lst.tail();
    while (!lcurrList.tail().isEmpty()) {
        const lcurr = lcurrList.head();
        lnext = lcurrList.tail();
        if (allSatisfy(lprev, lcurr, lnext.head())) {
            newList = node(lcurr, newList);
        }
        lprev = lcurr;
        lcurrList = lcurrList.tail();
    }
    return reverse(newList);
}
export function keepLocalMaxima(lst) {
    return keepTrendMiddles(lst, (prev, curr, next) => prev < curr && curr > next);
}
export function keepLocalMinima(lst) {
    return keepTrendMiddles(lst, (prev, curr, next) => prev > curr && curr < next);
}
export function keepLocalMinimaAndMaxima(lst) {
    return keepTrendMiddles(lst, (prev, curr, next) => (prev > curr && curr < next) || (prev < curr && curr > next));
}
function products(lst, func) {
    let counter = 1;
    return reverse(lst.reduce((acc, e) => {
        if (func(e)) {
            counter = counter * e;
            return node(counter, acc);
        }
        else {
            counter = 1;
            return acc;
        }
    }, empty()));
}
export function nonNegativeProducts(lst) {
    return products(lst, n => n >= 0);
}
export function negativeProducts(lst) {
    return products(lst, n => n < 0);
}
function deleteHelper(lst, el) {
    let deleted = false;
    return lst.reduce((acc, e) => {
        if (!deleted && el === e) {
            deleted = true;
            return acc;
        }
        else {
            return node(e, acc);
        }
    }, empty());
}
export function deleteFirst(lst, el) {
    return reverse(deleteHelper(lst, el));
}
export function deleteLast(lst, el) {
    const reversed = reverse(lst);
    return deleteHelper(reversed, el);
}
export function squashList(lst) {
    return reverse(lst.reduce((acc, e) => {
        if (typeof e === "number") {
            return node(e, acc);
        }
        else {
            const sum = e.reduce((prev, value) => {
                return prev + value;
            }, 0);
            return node(sum, acc);
        }
    }, empty()));
}
//# sourceMappingURL=lists.js.map